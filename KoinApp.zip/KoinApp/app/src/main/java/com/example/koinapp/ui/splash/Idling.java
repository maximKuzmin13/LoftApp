package com.example.koinapp.ui.splash;

public interface Idling {
    void busy();
    void idle();
}
