package com.example.koinapp.fcm;

import dagger.Module;

@Module
abstract class FcmModule {

}