package com.example.koinapp.data;

public enum SortBy {
    RANK,
    PRICE
}
