package com.example.koinapp.data;

import android.content.Context;

import androidx.annotation.NonNull;

public class TestCurrencyRepository extends CurrencyRepositoryImpl {
    public TestCurrencyRepository(@NonNull Context context) {
        super(context);
    }
}
